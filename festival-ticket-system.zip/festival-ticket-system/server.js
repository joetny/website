const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const nodemailer = require('nodemailer');
const QRCode = require('qrcode');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;
const ADMIN_PASSWORD = '1204';

app.use(cors());
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));

// In-memory ticket store
let tickets = [];

// Middleware to protect admin routes
function checkAdmin(req, res, next) {
  const password = req.headers['x-admin-password'];
  if (password !== ADMIN_PASSWORD) {
    return res.status(403).json({ success: false, message: 'Forbidden: Invalid admin password' });
  }
  next();
}

// Get all tickets (admin only)
app.get('/tickets', checkAdmin, (req, res) => {
  res.json(tickets);
});

// Create a new ticket
app.post('/tickets', (req, res) => {
  const { name, code } = req.body;
  if (!name || !code) {
    return res.json({ success: false, message: 'Name and code are required.' });
  }
  if (tickets.find(t => t.code === code)) {
    return res.json({ success: false, message: 'Ticket code already exists.' });
  }
  tickets.push({ name, code, used: false });
  res.json({ success: true });
});

// Mark ticket as used (admin only)
app.post('/tickets/:code/use', checkAdmin, (req, res) => {
  const code = req.params.code;
  const ticket = tickets.find(t => t.code === code);
  if (!ticket) {
    return res.json({ success: false, message: 'Ticket not found.' });
  }
  if (ticket.used) {
    return res.json({ success: false, message: 'Ticket already used.' });
  }
  ticket.used = true;
  res.json({ success: true });
});

// Send ticket QR code via email
app.post('/send', async (req, res) => {
  const { email, code } = req.body;
  if (!email || !code) {
    return res.status(400).json({ success: false, message: 'Email and code required' });
  }

  const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
      user: 'tonyjoe216@gmail.com',
      pass: 'uspt mzms ikbx zkav'
    }
  });

  try {
    const filePath = path.join(__dirname, `qr-${code}.png`);
    await QRCode.toFile(filePath, code);

    const mailOptions = {
      from: 'End of Year Festival <tonyjoe216@gmail.com>',
      to: email,
      subject: 'Your Festival Ticket QR Code',
      html: `
        <p>🎉 Thank you for your purchase!</p>
        <p><strong>Ticket Code:</strong> ${code}</p>
        <p>Scan this QR code at the entrance:</p>
        <img src="cid:qrcode" alt="QR Code" />
      `,
      attachments: [{
        filename: 'qrcode.png',
        path: filePath,
        cid: 'qrcode'
      }]
    };

    await transporter.sendMail(mailOptions);
    fs.unlink(filePath, err => {
      if (err) console.error('Failed to delete QR file:', err);
    });

    res.json({ success: true });
  } catch (error) {
    console.error('Email send error:', error);
    res.status(500).json({ success: false, message: 'Failed to send email' });
  }
});

// Fallback for 404
app.use((req, res) => {
  res.status(404).send('Not found');
});

// Start server
app.listen(PORT, () => {
  console.log(`✅ Backend running at http://localhost:${PORT}`);
});
