# End of Year Festival Ticket System

## Backend Setup

1. Navigate to the backend folder:
   ```sh
   cd festival-backend
   ```
2. Install dependencies:
   ```sh
   npm install
   ```
3. Start the backend server:
   ```sh
   npm start
   ```
4. Backend server will listen on port 3000 by default.

## Frontend Setup

- Simply open `index.html` in a modern browser.
- For CORS issues, run a simple local server inside the frontend folder:
  ```sh
  python -m http.server
  ```
- Then visit `http://localhost:8000` or the port shown.

## Admin Login

- Username: User5
- Password: 1204

## Features

- Pay button leads to payment link.
- Admin panel with QR code scanner for ticket validation.
- Add tickets via admin panel (name + code).
- Tickets verified and marked as used on backend.
- Instructions to generate QR codes:
  - Use any free QR code generator (e.g., https://www.qr-code-generator.com/)
  - Enter the ticket code exactly and save the QR code image for the ticket holder.

## Notes

- Tickets are stored in backend memory (will reset if server restarts).
- Scanner requires camera permission.
- Works on mobile and desktop browsers that support camera access.
